"""Init spectra data."""

from .spectra import FragmentType, Spectra
