"""Init plotting."""

from .plotting import *
from .plotting import _check_columns
